import java.io.*;
import java.util.*;

public class Solution {

	public static void main(String[] args) throws IOException {
		

		System.out.println("1. Total word count: " + wordCount(new File("passage.txt")) + "\n");

		HashMap<String, Integer> sortedWords = top10(new File("passage.txt"));

		System.out.println("The top 10 words are: ");
		int count = 0;
		for (String value : sortedWords.keySet()) {

			System.out.println((count + 1) + ". \"" + value + "\", appeared " + sortedWords.get(value) + " times");
			count++;
			if (count == 10)
				break;
		}

		System.out.println("\nThe last sentence on the file that contains the most used word (the):\n\""
				+ lastsentence(new File("passage.txt")) + "\"");

	}

	public static int wordCount(File f) throws FileNotFoundException { // This method reads in the file and counts the number of words
		Scanner input = new Scanner(f);

		int count = 0;
		while (input.hasNext()) {
			count = count + 1;
			input.next();
		}
		return count;
	}

	public static HashMap<String, Integer> top10(File f) throws FileNotFoundException { // this method reads in a file and returns a list of words sorted by the word with most occurrences 

		Scanner input = new Scanner(f);

		HashMap<String, Integer> words = new HashMap<String, Integer>(); // creates hashmap

		while (input.hasNext()) { // adds word to map

			String current = input.next().replaceAll("[^a-zA-Z ]", "").toLowerCase(); // since we only care about the words, and not punctuation, remove all punctuation and convert the word to lower case

			if (!words.containsKey(current)) { // if this is the first occurrence of the word
				words.put(current, 1);			// add the word with value 1
			} else {
				int count = words.get(current);
				words.put(current, count + 1); // otherwise add the value of the word by 1
			}

		}

		HashMap<String, Integer> sortedWords = new LinkedHashMap<String, Integer>(); // create a new map that will be sorted
		
		List<Map.Entry<String, Integer>> list = new LinkedList<Map.Entry<String, Integer>>(words.entrySet()); // create a list of the map entries (the key value pairs)

		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() { // sorts the list in descending order 
			public int compare(Map.Entry<String, Integer> val1, Map.Entry<String, Integer> val2) {
				return (val2.getValue()).compareTo(val1.getValue());
			}
		});

		for (Map.Entry<String, Integer> word : list) { // add the sorted entries to the new sortedMap
			sortedWords.put(word.getKey(), word.getValue());
		}

		return sortedWords;

	}


	public static String lastsentence(File f) throws FileNotFoundException { // this method finds the last sentence that contains the most used word
		Scanner input = new Scanner(f);
		String file = "";
		while (input.hasNextLine()) { // convert the file into 1 large string
			file += input.nextLine();
		}
		String[] sentences = file.split("\\.", -2); // creates an array of strings, where each string is a sentence, split on "." since that marks the end of a sentence

		HashMap<String, Integer> sortedWords = top10(f); // creates the sorted set of words

		String mostCommonWord = sortedWords.entrySet().iterator().next().getKey(); // gets the first word of the set, which would be the most common word

		String lastsentence = "";

		for (String sentence : sentences) { // for each sentence in the array of sentences

			if (sentence.contains(mostCommonWord)) { // if the sentence contains the most common word, store that sentence
				lastsentence = sentence; 			// since this loops until the last sentence, it will store the last sentence with the occurrence of the most common word
			}

		}

		return lastsentence.trim();

	}

}
